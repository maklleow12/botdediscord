export default interface SnowflakeEntity {
  id: string;
}